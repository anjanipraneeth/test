package com.TaxInfo.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}

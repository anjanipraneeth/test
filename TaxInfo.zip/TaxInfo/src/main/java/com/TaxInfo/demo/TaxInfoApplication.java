package com.TaxInfo.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxInfoApplication.class, args);
	}

}

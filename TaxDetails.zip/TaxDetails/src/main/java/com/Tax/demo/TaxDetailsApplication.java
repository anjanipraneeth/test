package com.Tax.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxDetailsApplication.class, args);
	}

}
